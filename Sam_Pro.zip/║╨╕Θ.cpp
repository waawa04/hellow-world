#include<iostream>
#include<string>
using namespace std;
int main() {
    cout << "char\tbinary\t\toctal\tdilgt\thexa" << endl;;
    int b[8] = { 0 };
    int o[3] = { 0 };
    char h[3] = { '0' };
    for (char a = 'A'; a < 'Z' + 1; a++) {
        int c = (int)a;
        int i = 7;
        while (i >= 0) {
            b[i] = c % 2;
            c = c / 2;
            i--;
        }
        c = (int)a;
        i = 2;
        while (i >= 0) {
            o[i] = c % 8;
            c = c / 8;
            i--;
        }
        c = (int)a;
        i = 1;
        while (i >= 0) {
            switch (c % 16) {
            case 10: h[i] = 'A'; break;
            case 11: h[i] = 'B'; break;
            case 12: h[i] = 'C'; break;
            case 13: h[i] = 'D'; break;
            case 14: h[i] = 'E'; break;
            case 15: h[i] = 'F'; break;
            default: h[i] = (c % 16);
            }
            c /= 16;
            i--;
        }
        cout << a << "\t" << b << "\t\t" << o << "\t" << (int)a << "\t" << h << "\t" << endl;
    }

	return 0;
}