#include<iostream>
using namespace std;
int main() {
	int max;
	int n;
	int mul=0;
	int cnt = 0;
	cout << "���� �Է� : ";
	cin >> n;
	
		
		
		
		for (int i = 1; i < n; i++){
			mul = i * i;
			cout << i-cnt << " ~ " << i << "������ �� : " << mul << endl; 
		cnt++;
		}
		
	return 0;
}