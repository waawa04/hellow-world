#include <stdio.h>
int main() {
	printf("char\tbinary\toctal\tdigit\thexa\n");
	printf("A\t"); 
	printf("\t");
	printf("%d",'A');
	printf("\t");
	printf("%o", 'A'); 
	printf("\t"); 
	printf("%x", 'A');
}