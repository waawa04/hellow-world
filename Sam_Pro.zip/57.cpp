#include <iostream>
using namespace std;
int main() {
	char str[15] = "HELLO WORLD";
	cout << str[0] << "(" << (int)str[0] << ")" << endl; //(int) �ƽ�Ű�ڵ� 
	cout << str[4] << "(" << (int)str[4] << ")" << endl;
	cout << str[5] << "(" << (int)str[5] << ")" << endl;
	cout << str[10] << "(" << (int)str[10] << ")" << endl;
	cout << str[11] << "(" << (int)str[11] << ")" << endl;

	return 0;
}