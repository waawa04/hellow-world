#include <iostream>
using namespace std;
int main() {
	int n;
	cout << "�� �Է� : ";
	cin >> n;
	int* arr;
	arr = (int*)malloc(sizeof(int) * n);

	for(int i = 0; i<sizeof(&arr); i++){
	cout << arr[i]<<" ";
	}

	
}