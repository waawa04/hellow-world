#include<iostream>
using namespace std;

int mul(int a, int b) {
	return a * b;
}
int main() {
	
	cout << mul(3, 5);
}