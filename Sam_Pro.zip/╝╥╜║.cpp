#include<iostream>
int main() {
	
	using namespace std;
	const char* pMessage = "welcome to korea";
	int cnt = sizeof(pMessage) / sizeof(int);
	for(int i=0; i<cnt!=NULL; i++)
		
	cout << i << endl;
}