#include <stdio.h>
int main() {
	int year=0;
	int yun = 0;
	printf("���� �Է� : ");
	scanf_s("%d", &year);
	if (year % 4 == 0 && !year % 100 == 0) {
		yun++;
	}
	printf("%d\n", yun);
	return 0;
}