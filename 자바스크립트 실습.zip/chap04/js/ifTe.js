"use strict";
let qustion = prompt("자바스크립트의 공식 이름은 무엇일까요?");
let answer = (qustion=="ECMAScript") ? "정답입니다!" :
"모르셨나요? 정답은 ECMAScript입니다!";
alert(answer);