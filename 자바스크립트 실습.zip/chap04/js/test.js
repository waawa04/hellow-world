"use strict";

function sum(one, two){
    return one+two;
}


alert(sum(1,3));

