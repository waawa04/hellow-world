"use strict";
function showMs(greeting, name = "UnKnown"){
    alert(name + " :" + greeting);
}
showMs("Hi");