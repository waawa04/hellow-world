"use strict";

let user = {
    name :"John",
    age : 30
};
let key=prompt("사용자의 어떤 정보를 얻고 싶으신가요? 키를 입력하세요");
alert(user[key]); //도트 연산자는 키 이름을 다같이 전달 불가.