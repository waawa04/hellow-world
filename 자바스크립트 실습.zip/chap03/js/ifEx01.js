'use strict';
let a = prompt("자바스크립트의 '공식' 이름은 무엇일까요?");
let message = (a == "ECMAScript") ? '정답입니다!':
'모르셨나요? 정답은 ECMAScript 입니다!';
alert(message);

/*if(a=="ECMA") {
    let a = prompt("자바스크립트의 '공식' 이름은 무엇일까요?");
 alert("정답입니다!");   
}
else {
    alert("모르셨나요? 정답은 ECMAScript 입니다!");
}*/