'use strict';
let input;

do{
    input = prompt("점수입력")

}while(input>=0 && input <=100 && input)