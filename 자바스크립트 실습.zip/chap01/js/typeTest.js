"use strict";
let name = "나미림";
const PI = 3.14;
console.log(typeof name);
console.log(typeof PI);
console.log(typeof 'a');
console.log(typeof "a");

name = 1; //동적 타입 언어
console.log(typeof name);