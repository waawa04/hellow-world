'use strict';

let hak;
let name;
hak = prompt("학번");
name = prompt("이름");

alert(`학번 : ${hak} 이름 : ${name}`);