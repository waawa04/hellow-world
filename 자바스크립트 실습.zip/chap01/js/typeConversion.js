'use strict';
let a;
let b;
a = prompt("숫자 1");
b = prompt("숫자 2");

alert(Number(a-b));