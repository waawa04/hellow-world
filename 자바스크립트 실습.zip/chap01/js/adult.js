"use strict";
let age = prompt("입력");
if(age >= 18 && age <= 100){

alert("성인");
}
