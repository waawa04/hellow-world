'use strick';

let name = "John";
alert(`Hello, ${name}`);