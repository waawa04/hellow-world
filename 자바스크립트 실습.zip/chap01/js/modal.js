let name;
name = prompt("이름을 입력하세요", "name");
alert(name);

let a,b;
a= prompt("숫자1 : ");
b= prompt("숫자2 : ");

alert(Number(a)+Number(b)); //int로 형변환 : Number() , parseInt()