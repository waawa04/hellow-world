"use strict";

console.log(1);
console.log(100.);
console.log(100.0000);
console.log(100.000000123);
console.log(Number.MAX_VALUE);
console.log(Number.MIN_VALUE);

const RED_C = "#F00";
console.log(RED_C);