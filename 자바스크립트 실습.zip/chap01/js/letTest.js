let a = 5;
let b = 3;

console.log(a+b); //코드 러너에서 출력문은 console.log();이다.