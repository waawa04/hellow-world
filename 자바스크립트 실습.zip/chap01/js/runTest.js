"use strict";

let name;
name = "홍길동";
console.log(name);